<?php
	// include connection.php
	if(isSet($_GET['iUpdate'])){
		$id = $_GET['iID'];
		$username= $_GET['iUsername'];
		if(isSet($id) && $username !="" $id!=""){
			$query = " UPDATE users SET username=$username WHERE userID=$id";
			$conn->query($query);
			$query = " SELECT userID, username FROM users WHERE userID=$id";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
	<form >
		<fieldset>
			<legend>Update Username</legend>
			<table class="updateform"
			>
				<tr class="updateform">
					<td class="updateform">ID 		: 	</td>
					<td class="updateform"><input type="text" name="iID"> </td>
				</tr>
				<tr class="updateform">
					<td class="updateform">New Username: </td>
					<td class="updateform"><input type="text" name="iUsername"> </td>
				</tr>
			</table>
						
					
			<input type="submit" name="iUpdate" value="UPDATE" >
		</fieldset>
		<br>
		<a href="users.php">BACK</a>
		<br>
		<br>
			
	</form>
	<?php

	?>
</body>
</html>